
***

# Git-image file naming training course

This basic training course will teach you the basics of my Git-image file organization systemn,

## Step 1: sort the files

The files have to be sorted. Let's start with GNOME System Monitor screenshots. There are 2 mega categories for this application: GNOME System Monitor and battery progress.

Battery progress shots will have a white box in the upper right corner of the screen. Any files you see with a white box like this should be categorized as a battery image directory, and should be placed in the battery directory, under the day it was from.

The other sub-categories for GNOME System Monitor include:

End of day (partitions)
End of day (Monitor)

Only the very last 2 files of the day contain this category, and should be named as such. The screenshot that shows partitions/drives is the complicated looking one. The screenshot that shows the monitor is everything but that.

## Step 2: rename the files

For GNOME System Monitor instructions, see step 1

To mention: DDS, GitHUb Milestones, GitHub end of day (profile) GitHub end of day (individual repositories) light mode and dark mode.

THIS COURSE IS CURRENTLY INCOMPLETE

***

## File info

**File type:** `Markdown document (*.md *.mkd *.mdown *.markdown)`

**File version:** `1 (2022 Wednesday, June 1st at 1:45 am)`

**Line count (including blank lines and compiler line):** `42`

**Current article languuage:** `English (USA)`

***
S
